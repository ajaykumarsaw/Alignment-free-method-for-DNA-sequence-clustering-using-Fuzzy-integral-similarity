#include<stdio.h>
#include<string.h>
#include<math.h>
#include <stdlib.h>
#include <inttypes.h>
#include <stdint.h>

// #define v_a 340   //*********** no of row in input file.
// #define v_b 34   //*********** number of species  ????????????????????????
// #define mal 32000 //*****************maximum length of DNA sequences ???????????????????????

// THIS CODE IS WRITTEN FOR PHYLIP PACKAGE FOR MAINTAINING STRING LENGTH 10 AND ADDING SPACE LENGTH 5.


int  main(int argc, char *argv[])

{
if (argc==6)
{ //*************************************

int v_b, mal, len_k;  // ************no of species ,  maximum length of DNA and optimal K

v_b=atoi(argv[1]);

mal=atoi(argv[2]);

len_k=atoi(argv[3]);

int v_a=v_b*10;
int s=len_k;  // optimize k for input file for PHYLIP package   ??????????????????????????
int e=v_b*(s-1);  // multiply (s-1) by number of species.....

int i_1,j_1;
float a[v_a][v_b];
FILE *input1;
input1= fopen(argv[4],"r"); // path of input file for similarity matrix.????????????????????????
for(i_1=0;i_1<v_a;i_1++)
for(j_1=0;j_1<v_b;j_1++)
fscanf(input1,"%f",&a[i_1][j_1]);
fclose(input1);
//#################################################################################
i_1=-1;

char *dna;
dna=(char*) malloc(mal*sizeof(char));

int r_1=0;
printf("    %d",v_b); // number of species in first coulmn......??????????????????????????????????????????????????
printf("\n");

FILE *input;
input= fopen(argv[5],"r"); // raw file of sequence with name ????????????????????????????????
while(fgets(dna,mal,input)!=NULL)
{
r_1++;  //  ##########
if((r_1%2)!=0)  // ***for reading odd line from input file******
{ 
int l=strlen(dna);
 // printf("%d    ",l);
int i; 

for(i=1;i<11;i++)
printf("%c",dna[i]);
printf("     ");


i_1++;
for(j_1=0;j_1<v_b-1;j_1++)  
printf("%f  ",a[e+i_1][j_1]);
printf("%f",a[e+i_1][v_b-1]);
printf("\n");


} // ***************** end if loop(help to directly read from fasta file)
} //end while loop
fclose(input);

} //************************************

else if (argc < 6 || argc > 6)
{
printf("Enter Five  arguments: 1_number_of_DNA_sequences  2_maximum_length_among_DNA_sequences 3_optimal_order_k 4_input_path_file 5_sequence_file");
printf("\n");
}

return(0);


}


