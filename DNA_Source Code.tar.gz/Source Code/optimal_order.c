#include<stdio.h>
#include<string.h>
#include<math.h>
// #define v_a 340   //*********** no of row in input file.
// #define v_c 34  //****************no of species  ?????????????????????????????????


int main(int argc, char *argv[])
{

if (argc==3)
{ //*************************************

int v_c;  // ************no of species  ?????????????????????
v_c=atoi(argv[2]);

int v_a= v_c*10;
float a[v_a][v_c];
int i,j,m=v_a,n=v_c;
FILE *input;
input= fopen(argv[1],"r"); //  ?????????????????????????????????
for(i=0;i<m;i++)
for(j=0;j<n;j++)
fscanf(input,"%f",&a[i][j]);

float sum,b[10];

int k,l,t,z=0;
for(k=0;k<m-v_c;k=k+v_c)
{
l=k+v_c;
sum=0;
z++;
for(t=0;t<n;t++)
for(i=0;i<n;i++)
{
b[z]=(float)(a[k+t][i]-a[t+l][i]);
sum=sum+(b[z]*b[z]);
}
b[z]=sum/(v_c*v_c);
b[z]= sqrt(b[z]);

 printf("root mean square difference between %d and %d is %f", z, z+1, b[z]);
 printf("\n");
if(b[z]<=(float)0.000000499)
{
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("Therefore k= %d is optimal step for generating distance matrix for phylogenetic tree construction.", z);
break;
}

}
printf("\n");

} //************************************

else if (argc < 3 ||argc > 3)
{
printf("Enter Two arguments: 1_path_of_input_file  2_number_of_DNA_sequences");
printf("\n");
}




return(0);
}
