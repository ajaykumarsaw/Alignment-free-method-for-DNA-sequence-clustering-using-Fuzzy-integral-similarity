#include<stdio.h>
#include<stdlib.h>
#include<math.h>
// #define v_a 340   //*********** no of row in input file.
#define v_b 16   //*********** no of column in input file.
//#define v_c 34  //****************no of species  ???????????????????????????????????

//*****take upto k=1 step and each step take upto 10 order**************



int main(int argc, char *argv[])
{

if (argc==3)
{ //*************************************


int  v_c;  // number of species
v_c=atoi(argv[2]);

int v_a = v_c*10;
float a[v_a][v_b];
int w,k,i,j,n=v_b,m=v_a;  // m is number of column.....in input file

FILE *input;
input=  fopen(argv[1],"r"); // path of the input file  ???????????????????????????????
for(i=0;i<m;i++)
for(j=0;j<n;j++)
fscanf(input,"%f",&a[i][j]);

// *****************extracting data for each k in a given sequence*************************
for(k=0;k<m;k=k+v_a)     // for each k-step 
for(w=0;w<10;w++)            // *******************morkov order*****************************
{
for(i=0;i<v_c;i++)   // *******************number of species*****************************
{
for(j=0;j<n;j++)
printf("%f  ", a[(10*i)+w+k][j]);
printf("\n");
}
//printf("\n");
}
fclose(input);

} //*******************************************

else if (argc < 3 ||argc > 3)
{
printf("Enter Two arguments: 1_path_of_input_file 2_number_of_DNA_sequences");
printf("\n");
}


return(0);
}
