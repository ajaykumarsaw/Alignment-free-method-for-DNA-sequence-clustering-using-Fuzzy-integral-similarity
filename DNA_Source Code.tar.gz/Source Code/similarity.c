#include<stdio.h>
#include<string.h>
#include<math.h>
// #define v 340  // *********** no of rows in input file.
// #define s_1 34   // **** no of species  ??????????????????????????????????
int main(int argc, char *argv[])
{

if (argc==3)
{ //*************************************


int s_1;  // **** no of species
s_1=atoi(argv[2]);

int v=s_1*10, q;

for(q=0;q<v;q=q+s_1)  // ***********1*************(for identification)
{
/*printf("FuzzY IntegraL SimilaritY");
printf("\n");
printf("\n");*/
int x,i,j,k,p,t,m=s_1,n=16;
float temp=0,temp1=0;
t= (m*(m-1))/2;
float a[v][16];
float c[t][16],b[t][16],d[t][16],e[t][16];

for(i=0;i<v;i++)
for(j=0;j<n;j++)
 a[i][j]=0;

for(p=0;p<t;p++)
for(j=0;j<n;j++)
 {
d[p][j]=0;
c[p][j]=0;
 b[p][j]=0;
e[p][j]=0;
}

FILE *input;
input= fopen(argv[1],"r");  // keep in mind arrange.txt  ?????????????????????????????????????
for(i=0;i<v;i++)
for(j=0;j<n;j++)
fscanf(input,"%f",&a[i][j]);




//printf("calculation for mu slot"); 
// -----------------------------------------------
//printf("\n");
//printf("\n");

p=-1;
for(i=0;i<m-1;i++)
for(k=i+1;k<m;k++)
{
p++;
for(j=0;j<n;j++)
{
if(a[i+q][j]>a[k+q][j])
{
b[p][j]=a[i+q][j];
// printf("%f  ",b[p][j]);
}
else
{
b[p][j]=a[k+q][j];
// printf("%f  ",b[p][j]);
}
}
// printf("\n");
}
/*
for(i=0;i<t;i++)
{
for(j=0;j<n;j++)
//printf("%f  ",b[i][j]);
// printf("\n");
} */
 // -------------------------------------------
//printf("\n");
//printf("\n");

// printf(" CALCULATION for lambda value using  NEWTON RAPSON METHOD");
//--------------------------------

//printf("\n ----------------------------------------------------");
//printf("CALCULATE COEFFICIENT -------------------");
//printf("\n");
//printf("\n");
for(i=0;i<t;i++)
for(j=0;j<n;j=j+4)
{
d[i][j]=(b[i][j+0]*b[i][j+1]*b[i][j+2]*b[i][j+3]);
d[i][j+1]=((b[i][j+0]*b[i][j+1]*b[i][j+2])+(b[i][j+0]*b[i][j+1]*b[i][j+3])+(b[i][j+0]*b[i][j+2]*b[i][j+3])+(b[i][j+1]*b[i][j+2]*b[i][j+3]));
d[i][j+2]=((b[i][j+0]*b[i][j+1])+(b[i][j+0]*b[i][j+2])+(b[i][j+0]*b[i][j+3])+(b[i][j+1]*b[i][j+2])+(b[i][j+1]*b[i][j+3])+(b[i][j+2]*b[i][j+3]));
d[i][j+3]=(b[i][j+0]+b[i][j+1]+b[i][j+2]+b[i][j+3])-1;
}
/*
for(i=0;i<t;i++)
{
for(j=0;j<n;j++)
{
//printf("%f  ",d[i][j]);
}
//printf("\n");
}

//printf("\n");
//printf("\n");
//printf("\n -----------------------------------------------------");
//---------------------------------------
//printf("CALCULATE LAMBDA");
//printf("\n");
//printf("\n"); */
int cnt;
float x1,x2,z,fx1,fdx1;
for(j=0;j<t;j++)
 {
 for(k=0;k<n;k=k+4)
 {

cnt=0,x1=0.5,x2=0,z=0;

    do
    {
            cnt++;
            fx1=fdx1=0;
            for(i=3;i>=1;i--)

            {
                fx1+=d[j][3-i+k] * (pow(x1,i)) ;
            }
            fx1+=d[j][0+k+3];
            for(i=3;i>=1;i--)
            {
                fdx1+=d[j][3-i+k]* (i*pow(x1,(i-1)));
            }

            x2=(x1-(fx1/fdx1));
            z=x1;
            x1=x2;

            //printf("\n %d         %.3f  %.3f  %.3f ",cnt,x1,fx1,fdx1);
// printf("\n");

    }while(fabs(z - x1)>=0.0001);
   /* printf("\n\t THE ROOT OF EQUATION IS %f",x1);  */
  e[j][k]=x1;

}
}
/*
for(i=0;i<t;i++)
{
for(j=0;j<n;j=j+4)
//printf("%f  ", e[i][j]);

//printf("\n");
}

//---------------------------------------

//printf("\n ------------------------------------");
//printf("\n -------------------------------------");
//printf("\n-------------------------------------");











//printf("CALCULATION OF H(I)  THAN SORTING IN DECENDING ORDER AND ARRANGE MU VALUE WITH RESPECT TO H(I)");
//printf("\n");
//printf("\n");
//---------------------------------------------------
//----------------------------------------------------- */
p=-1;

for(i=0;i<m-1;i++)
for(k=i+1;k<m;k++)
{ 
p++;
for(j=0;j<n;j++)
{
c[p][j]= (float)1-( fabs(a[i+q][j]-a[k+q][j]));

// printf("%f  ",c[p][j]);
}
//printf("\n");
}

/*SORTING ARRAY IN DECREASING ORDER */



/*Array sorting code */
for(k=0;k<t;k++)
for(x=0;x<n;x=x+4)
for(i=0;i<3;i++)
for(j=i+1;j<4;j++)
if(c[k][x+j]>c[k][x+i])
{
temp=c[k][x+i];
c[k][x+i]=c[k][x+j];
c[k][x+j]=temp;

temp1=b[k][x+i];
b[k][x+i]=b[k][x+j];
b[k][x+j]=temp1;
}

//printf("print sorting value");
//printf("\n");
//printf("\n");
 
/* 
for(i=0;i<t;i++)
{
for(j=0;j<n;j++)
//printf("%f  ", c[i][j]);
//printf("\n");
}
//printf("\n-----------------");
//printf("\n----------------");
//printf("\n--------------------");
//printf(" PRINT MU VALUE AFTER ARRANGEMENT ACCORDING AS H(I)");
//printf("\n");
//printf("\n");
for(i=0;i<t;i++)
{
for(j=0;j<n;j++)
//printf("%f  ",b[i][j]);
//printf("\n");
}


//-------------------------------------------
//---------------------------------------------


printf("\n-----------------------------");
printf("\n------------------------");
printf("\n-------------------------");

printf("CALCULATE A[I]");
printf("\n");
printf("\n"); */
for(i=0;i<t;i++)
for(j=0;j<n;j=j+4)
{
d[i][0+j]=b[i][0+j];
d[i][1+j]=b[i][1+j]+d[i][0+j] + e[i][0+j]*b[i][1+j]*d[i][0+j];
d[i][2+j]=b[i][2+j]+d[i][1+j] + e[i][0+j]*b[i][2+j]*d[i][1+j];
d[i][3+j]=b[i][3+j]+d[i][2+j] + e[i][0+j]*b[i][3+j]*d[i][2+j];
}
/*
for(i=0;i<t;i++)
{
for(j=0;j<n;j++)
//printf("%f  ",d[i][j]);
//printf("\n");
}


printf("\n");
printf("\n");
printf("CALCULATE MINIMUM BETWEEN D[i][j] AND C[i][j]");

printf("\n");
printf("\n");
printf("\n");
*/
for(i=0;i<t;i++)
for(k=0;k<n;k++)
{
if(c[i][k]<d[i][k])
{
b[i][k]=c[i][k];
// printf("%f  ",b[p][j]);
}
else
{
b[i][k]=d[i][k];
// printf("%f  ",b[p][j]);
}
}
// printf("\n");

/*
for(i=0;i<t;i++)
{
for(j=0;j<n;j++)
printf("%f  ",b[i][j]);
printf("\n");
}

printf("\n-------------------");
printf("\n");
printf("\n");

printf("CALCULATE MAXIMUM");
printf("\n");
printf("\n");
*/
float max=0;
for(i=0;i<t;i++)
{
for(j=0;j<n;j=j+4)
{
max=b[i][j];
for(k=0;k<4;k++)
{
if(max < b[i][k+j])
{
max=b[i][j+k];
}
}
e[i][j]=max;
// printf("%f  ",e[i][j]);
}
// printf("\n");
}
/*
printf("\n");
printf("\n");
printf("\n");

printf("CALCULATE MAXIMUM");
printf("\n");
printf("\n");
*/

float g[t],maxx=0;

for(i=0;i<t;i++)
{
maxx=e[i][0];
for(k=0;k<n;k=k+4)
{
if(maxx < e[i][k])
{
maxx=e[i][k];
}
}
g[i]=maxx;
g[i]=1-g[i]; // for getting disimiliarity matrix
// printf("%f  ",g[i]);
//printf("\n");
}
// printf("\n");

float r[s_1][s_1];

for(i=0;i<s_1;i++)
for(k=0;k<s_1;k++)
r[i][k]=0;

int u=-1;
for(i=0;i<s_1-1;i++)
for(k=i+1;k<s_1;k++)
{
u++;
r[k][i]=r[i][k]=g[u];
}


for(i=0;i<s_1;i++)
{
for(k=0;k<s_1;k++)
printf("%f  ",r[i][k]);
printf("\n");
}
//printf("\n");
//printf("\n");
} //  ***********1*************(for identification)

} // **********************************

else if (argc < 3 ||argc > 3)
{
printf("Enter Two arguments: 1_path_of_input_file  2_number_of_DNA_sequences");
printf("\n");
}


return(0);
}

