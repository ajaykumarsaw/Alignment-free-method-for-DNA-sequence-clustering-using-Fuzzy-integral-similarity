#include<stdio.h>
#include<string.h>
#include<math.h>
#include <stdlib.h>
#include <inttypes.h>
#include <stdint.h>

int main(int argc, char *argv[])
{
if (argc==3)
{ //*************************************

int mal;  // argument second is the maximum length of  DNA sequences   ?????????????????????????????????
mal=atoi(argv[2]);

int k;  // ****************************change parameter*****************
 for(k=1;k<2;k++) // *********k-th step ****for loop*******************
{
/*Input of DNA of length of nucleotides  in 1 line */
char *dna;
dna=(char*) malloc(mal*sizeof(char));
int r_1=0;  // ***********
FILE *input;
input= fopen(argv[1],"r"); // argument first is the Path of  input file  ??????????????????????????????????
while(fgets(dna,mal,input)!=NULL)
{
r_1++;  //  for reading even line from input file
if((r_1%2)==0)  // *********
{  //*********

/* Count frequency of symbol */
int i,j,l,N[4][4];
float    P[4][4],U[4][4],Q[4][4];


for(i=0;i<4;i++)
for(j=0;j<4;j++)
 N[i][j]=0;

for(i=0;i<4;i++)
for(j=0;j<4;j++)
{
P[i][j]=0;
U[i][j]=0;
Q[i][j]=0;
}
int srr;
srr= strlen(dna);

for(l=0;l<=srr;l++)
{
if (dna[l]=='A')
{
if((l+k)<= srr)
{
i=0;
if (dna[l+k]=='A')
N[i][0]+=1;
else if (dna[l+k]=='T')
N[i][1]+=1;
else if (dna[l+k]=='G')
N[i][2]+=1;
else if (dna[l+k]=='C')
N[i][3]+=1;
}
}

else if (dna[l]=='T' )
{
if((l+k)<= srr)
{
i=1;
if (dna[l+k]=='A')
N[i][0]+=1;
else if (dna[l+k]=='T')
N[i][1]+=1;
else if (dna[l+k]=='G')
N[i][2]+=1;
else if (dna[l+k]=='C')
N[i][3]+=1;
}
}
 else if (dna[l]=='G' )
{
if((l+k)<= srr)
{
i=2;
if (dna[l+k]=='A')
N[i][0]+=1;
else if (dna[l+k]=='T')
N[i][1]+=1;
else if (dna[l+k]=='G')
N[i][2]+=1;
else if (dna[l+k]=='C')
N[i][3]+=1;
}
}
else if (dna[l]=='C' )
{
if((l+k)<= srr)
{
i=3;
if (dna[l+k]=='A')
N[i][0]+=1;
else if (dna[l+k]=='T')
N[i][1]+=1;
else if (dna[l+k]=='G')
N[i][2]+=1;
else if (dna[l+k]=='C')
N[i][3]+=1;
}
}

}

 /* Output frequency of DNA nucleotides */
/*
for(i=0;i<4;i++)
for(j=0;j<4;j++)
printf("%d  ",N[i][j]);
printf("\n");
*/

/*output probability of dna sequence */


for(i=0;i<4;i++)
for(j=0;j<4;j++)
{
U[i][j]=P[i][j]=(float   )N[i][j]/(N[i][0]+N[i][1]+N[i][2]+N[i][3]);
printf("%f  ",P[i][j]);
}
printf("\n");

float  sum;
int w;

for(w=2;w<11;w++)  // **********morkov order *******change Parameter*******************************
{
for(i=0;i<4;i++)
for(j=0;j<4;j++)
{
sum=0;
for(l=0;l<4;l++)
{
Q[i][j]=U[i][l]*P[l][j];
sum=sum+Q[i][j];
}
Q[i][j]=sum;
printf("%f  ",Q[i][j]);

}
for(i=0;i<4;i++)
for(j=0;j<4;j++)
U[i][j]=Q[i][j];

printf("\n");
}



}
}  // end of while loop
fclose(input);

}  // **********************finish for loop**********************

} //************************************

else if (argc < 3 ||argc > 3)
{
printf("Enter Two arguments. 1_path_of_input_file  2_maximum_length_of_DNA_sequences");
printf("\n");
}

return(0);


}

